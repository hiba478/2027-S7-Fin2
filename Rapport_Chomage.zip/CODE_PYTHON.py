# ============================================================
# SCRIPT PROFESSIONNEL : analyse + graphiques (style avancé)
# Source : HCP, indicateurs trimestriels du marché du travail (EMO), 2017-2025
# ============================================================

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np

# ------------------------------------------------------------------
# 0. STYLE GLOBAL (rend tous les graphiques plus "pro")
# ------------------------------------------------------------------
plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#333333",
    "axes.labelcolor": "#222222",
    "axes.titleweight": "bold",
    "axes.titlesize": 14,
    "axes.titlepad": 14,
    "axes.grid": True,
    "grid.color": "#dddddd",
    "grid.linewidth": 0.6,
    "font.size": 10.5,
    "font.family": "DejaVu Sans",
    "xtick.color": "#333333",
    "ytick.color": "#333333",
    "legend.frameon": False,
})

NAVY = "#1f3d7a"
RED = "#c1272d"
GREEN = "#2e8b57"
ORANGE = "#f4a300"
PURPLE = "#8e44ad"
BLUE = "#3b7dd8"
PINK = "#d84f8c"
TEAL = "#117a65"
BROWN = "#922b21"


# ------------------------------------------------------------------
# 1. IMPORT DES DONNEES
# ------------------------------------------------------------------
df = pd.read_excel("donnees_hcp.xlsx", sheet_name="Données")
df["periode"] = df["AN"].astype(str) + "-T" + df["TRIM"].astype(str)
annuel = df.groupby("AN").mean(numeric_only=True).round(1)
x = df["periode"]


def style_axes(ax):
    """Ajoute un cadre propre + un fond légèrement grisé sous la légende."""
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.yaxis.set_major_formatter(mticker.FormatStrFormatter("%.0f%%"))


def annoter_extremes(ax, x, y, couleur):
    """Annote le point le plus haut et le plus bas d'une courbe."""
    imax, imin = np.argmax(y), np.argmin(y)
    ax.annotate(f"Max: {y.iloc[imax]:.1f}%", xy=(imax, y.iloc[imax]),
                xytext=(0, 10), textcoords="offset points",
                ha="center", fontsize=8, fontweight="bold", color=couleur)
    ax.annotate(f"Min: {y.iloc[imin]:.1f}%", xy=(imin, y.iloc[imin]),
                xytext=(0, -14), textcoords="offset points",
                ha="center", fontsize=8, fontweight="bold", color=couleur)


# ------------------------------------------------------------------
# GRAPHE 1 : Taux de chômage national + zone de récession Covid
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6.5))
ax.plot(x, df["TX.CH.STR"], color=NAVY, linewidth=2.8, marker="o", markersize=3)
ax.axvspan(9.5, 11.5, color="grey", alpha=0.15)  # zone Covid approx (2019T4-2020T4)
ax.text(10.5, ax.get_ylim()[1] * 0.97, "Choc\nCOVID-19", ha="center", va="top",
        fontsize=8.5, color="grey", fontweight="bold")
annoter_extremes(ax, x, df["TX.CH.STR"], NAVY)
style_axes(ax)
ax.set_title("Taux de chômage national — évolution trimestrielle (2017-2025)")
ax.set_xlabel("Trimestre")
ax.set_ylabel("Taux de chômage")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig("pro_g1_national.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 2 : Urbain vs Rural (zone remplie pour montrer l'écart)
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6.5))
ax.plot(x, df["TX.CH.STR.U"], color=RED, linewidth=2.4, label="Urbain")
ax.plot(x, df["TX.CH.STR.R"], color=GREEN, linewidth=2.4, label="Rural")
ax.fill_between(range(len(x)), df["TX.CH.STR.U"], df["TX.CH.STR.R"], color=RED, alpha=0.06)
style_axes(ax)
ax.set_title("Écart de chômage entre milieu urbain et milieu rural")
ax.set_xlabel("Trimestre")
ax.set_ylabel("Taux de chômage")
ax.legend(loc="upper left")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig("pro_g2_urbain_rural.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 3 : Hommes vs Femmes (écart annoté)
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6.5))
ax.plot(x, df["TX.CH.STR.H"], color=BLUE, linewidth=2.4, label="Hommes")
ax.plot(x, df["TX.CH.STR.F"], color=PINK, linewidth=2.4, label="Femmes")
ecart_debut = df["TX.CH.STR.F"].iloc[0] - df["TX.CH.STR.H"].iloc[0]
ecart_fin = df["TX.CH.STR.F"].iloc[-1] - df["TX.CH.STR.H"].iloc[-1]
ax.annotate(f"Écart {df['AN'].iloc[0]}: {ecart_debut:.1f} pts", xy=(0, df["TX.CH.STR.F"].iloc[0]),
            xytext=(2, df["TX.CH.STR.F"].iloc[0] + 2), fontsize=8, color=PINK, fontweight="bold")
ax.annotate(f"Écart {df['AN'].iloc[-1]}: {ecart_fin:.1f} pts", xy=(len(x) - 1, df["TX.CH.STR.F"].iloc[-1]),
            xytext=(len(x) - 9, df["TX.CH.STR.F"].iloc[-1] + 1.5), fontsize=8, color=PINK, fontweight="bold")
style_axes(ax)
ax.set_title("Chômage selon le sexe : un écart qui se creuse")
ax.set_xlabel("Trimestre")
ax.set_ylabel("Taux de chômage")
ax.legend(loc="upper left")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig("pro_g3_hommes_femmes.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 4 : Par tranche d'âge
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6.5))
ax.plot(x, df["TX.CH.STR15-24"], color=ORANGE, linewidth=2.6, label="15-24 ans")
ax.plot(x, df["TX.CH.STR25-34"], color=PURPLE, linewidth=2.2, label="25-34 ans")
ax.plot(x, df["TX.CH.STR35+"], color=GREEN, linewidth=2.2, label="35 ans et +")
style_axes(ax)
ax.set_title("Le chômage frappe en priorité les jeunes")
ax.set_xlabel("Trimestre")
ax.set_ylabel("Taux de chômage")
ax.legend(loc="upper left")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig("pro_g4_par_age.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 5 : Taux d'emploi (aire sous la courbe)
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6.5))
ax.plot(x, df["TX.EMP.REV"], color=TEAL, linewidth=2.6)
ax.fill_between(range(len(x)), df["TX.EMP.REV"], df["TX.EMP.REV"].min(), color=TEAL, alpha=0.12)
style_axes(ax)
ax.set_title("Taux d'emploi national — une baisse continue")
ax.set_xlabel("Trimestre")
ax.set_ylabel("Taux d'emploi")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig("pro_g5_taux_emploi.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 6 : Participation (national / hommes / femmes)
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6.5))
ax.plot(x, df["TX.PART.MO"], color=NAVY, linewidth=2.6, label="National")
ax.plot(x, df["TX.PART.MO.H"], color=BLUE, linewidth=2, linestyle="--", label="Hommes")
ax.plot(x, df["TX.PART.MO.F"], color=PINK, linewidth=2, linestyle="--", label="Femmes")
style_axes(ax)
ax.set_title("Taux de participation à la main-d'œuvre")
ax.set_xlabel("Trimestre")
ax.set_ylabel("Taux de participation")
ax.legend(loc="upper right")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig("pro_g6_participation.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 7 : Volume de chômeurs (aire)
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(13, 6.5))
ax.plot(x, df["POP.CH.STR"], color=BROWN, linewidth=2.6)
ax.fill_between(range(len(x)), df["POP.CH.STR"], df["POP.CH.STR"].min(), color=BROWN, alpha=0.12)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v, p: f"{v:,.0f}".replace(",", " ")))
for spine in ["top", "right"]:
    ax.spines[spine].set_visible(False)
ax.set_title("Nombre total de chômeurs (en milliers)")
ax.set_xlabel("Trimestre")
ax.set_ylabel("Chômeurs (milliers)")
plt.xticks(rotation=90, fontsize=7)
plt.tight_layout()
plt.savefig("pro_g7_volume_chomeurs.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 8 : National vs Jeunes (barres annuelles + valeurs affichées)
# ------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(12, 6.5))
annees = annuel.index.astype(str)
w = 0.35
pos = np.arange(len(annees))
b1 = ax.bar(pos - w/2, annuel["TX.CH.STR"], width=w, label="National", color=NAVY)
b2 = ax.bar(pos + w/2, annuel["TX.CH.STR15-24"], width=w, label="Jeunes 15-24 ans", color=ORANGE)
ax.bar_label(b1, fmt="%.1f", fontsize=7, padding=2)
ax.bar_label(b2, fmt="%.1f", fontsize=7, padding=2)
plt.xticks(pos, annees)
for spine in ["top", "right"]:
    ax.spines[spine].set_visible(False)
ax.set_title("Écart national / jeunes — moyennes annuelles")
ax.set_ylabel("Taux de chômage")
ax.legend()
plt.tight_layout()
plt.savefig("pro_g8_national_vs_jeunes.png", dpi=200)
plt.close()

# ------------------------------------------------------------------
# GRAPHE 9 (BONUS) : Dashboard 4-en-1, vue d'ensemble synthétique
# ------------------------------------------------------------------
fig, axes = plt.subplots(2, 2, figsize=(15, 10))
fig.suptitle("Tableau de bord synthétique — marché du travail marocain (2017-2025)",
             fontsize=15, fontweight="bold", y=0.98)

ax = axes[0, 0]
ax.plot(x, df["TX.CH.STR"], color=NAVY, linewidth=2)
ax.set_title("Chômage national")
ax.tick_params(axis="x", labelrotation=90, labelsize=6)
for s in ["top", "right"]:
    ax.spines[s].set_visible(False)

ax = axes[0, 1]
ax.plot(x, df["TX.CH.STR15-24"], color=ORANGE, linewidth=2)
ax.set_title("Chômage des jeunes (15-24 ans)")
ax.tick_params(axis="x", labelrotation=90, labelsize=6)
for s in ["top", "right"]:
    ax.spines[s].set_visible(False)

ax = axes[1, 0]
ax.plot(x, df["TX.CH.STR.F"], color=PINK, linewidth=2, label="Femmes")
ax.plot(x, df["TX.CH.STR.H"], color=BLUE, linewidth=2, label="Hommes")
ax.set_title("Chômage par sexe")
ax.legend(fontsize=8)
ax.tick_params(axis="x", labelrotation=90, labelsize=6)
for s in ["top", "right"]:
    ax.spines[s].set_visible(False)

ax = axes[1, 1]
ax.plot(x, df["TX.EMP.REV"], color=TEAL, linewidth=2)
ax.set_title("Taux d'emploi")
ax.tick_params(axis="x", labelrotation=90, labelsize=6)
for s in ["top", "right"]:
    ax.spines[s].set_visible(False)

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.savefig("pro_g9_dashboard.png", dpi=200)
plt.close()

print("Tous les graphiques professionnels ont été générés.")